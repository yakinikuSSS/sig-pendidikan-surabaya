import L, { type LatLng, type LatLngBoundsExpression } from "leaflet";
import { useMemo, useState } from "react";
import { MapContainer, TileLayer, ZoomControl } from "react-leaflet";
import { ChoroplethLayer } from "./components/ChoroplethLayer";
import { KecamatanPopup } from "./components/KecamatanPopup";
import { LayerToggle } from "./components/LayerToggle";
import { Legend } from "./components/Legend";
import { MapController } from "./components/MapController";
import { Sidebar } from "./components/Sidebar";
import { pendidikanData, surabayaGeoJson, umurData } from "./data";
import "./styles.css";
import type { FlyTarget, KecamatanFeature, MetricKey } from "./types";
import {
  buildMetricsByKecamatan,
  computeCityAverageBeban,
  createMetricScale,
  getMetricValue,
  normalizeKecamatanName,
  rankKecamatan,
} from "./utils/metrics";

const SURABAYA_CENTER: [number, number] = [-7.2575, 112.7521];
const SURABAYA_BOUNDS: LatLngBoundsExpression = [
  [-7.36, 112.58],
  [-7.16, 112.86],
];

function getFeatureName(feature: KecamatanFeature) {
  const rawName = feature.properties?.name ?? feature.properties?.NAME_3 ?? feature.properties?.kecamatan ?? "";
  return normalizeKecamatanName(String(rawName));
}

function boundsForFeature(feature: KecamatanFeature): [[number, number], [number, number]] {
  const bounds = L.geoJSON(feature).getBounds();
  const southWest = bounds.getSouthWest();
  const northEast = bounds.getNorthEast();
  return [
    [southWest.lat, southWest.lng],
    [northEast.lat, northEast.lng],
  ];
}

export default function MapApps() {
  const [activeMetric, setActiveMetric] = useState<MetricKey>("pemerataan");
  const [selectedName, setSelectedName] = useState<string | null>(null);
  const [flyTarget, setFlyTarget] = useState<FlyTarget | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const metricsByName = useMemo(() => buildMetricsByKecamatan(pendidikanData, umurData), []);

  const featureByName = useMemo(() => {
    return surabayaGeoJson.features.reduce<Record<string, KecamatanFeature>>((acc, feature) => {
      acc[getFeatureName(feature)] = feature;
      return acc;
    }, {});
  }, []);

  const metricValues = useMemo(
    () => Object.values(metricsByName).map((metrics) => getMetricValue(metrics, activeMetric)),
    [activeMetric, metricsByName],
  );

  const metricScale = useMemo(
    () => createMetricScale(activeMetric, metricValues),
    [activeMetric, metricValues],
  );

  const rankings = useMemo(
    () => rankKecamatan(metricsByName, activeMetric, metricScale),
    [activeMetric, metricScale, metricsByName],
  );

  const cityAverageBeban = useMemo(() => computeCityAverageBeban(metricsByName), [metricsByName]);

  const selectedMetrics = selectedName ? metricsByName[selectedName] : null;
  const selectedRank = selectedName ? rankings.find((row) => row.name === selectedName)?.rank ?? 0 : 0;

  const openKecamatan = (name: string) => {
    const normalizedName = normalizeKecamatanName(name);
    setSelectedName(normalizedName);
  };

  const handleMapSelect = (name: string, _position: LatLng) => {
    openKecamatan(name);
  };

  const handleSidebarSelect = (name: string) => {
    const feature = featureByName[normalizeKecamatanName(name)];
    if (!feature) return;

    const bounds = boundsForFeature(feature);
    openKecamatan(name);
    setFlyTarget({
      name,
      bounds,
      requestId: Date.now(),
    });
  };

  const closePopup = () => {
    setSelectedName(null);
  };

  return (
    <div className="alt5-app">
      <header className="alt5-header">
        <div className="alt5-header-mark" aria-hidden="true">
          <span />
        </div>
        <h1>Peta Pendidikan Surabaya</h1>
      </header>

      <main className={`alt5-map-shell ${selectedMetrics ? "has-detail" : ""}`}>
        <MapContainer
          center={SURABAYA_CENTER}
          zoom={12}
          minZoom={11}
          maxZoom={16}
          maxBounds={SURABAYA_BOUNDS}
          maxBoundsViscosity={0.35}
          scrollWheelZoom
          zoomControl={false}
          className="alt5-map"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
            url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
          />

          <ChoroplethLayer
            activeMetric={activeMetric}
            geoData={surabayaGeoJson}
            metricsByName={metricsByName}
            onSelect={handleMapSelect}
            scale={metricScale}
            selectedName={selectedName}
          />

          <MapController flyTarget={flyTarget} />
          <ZoomControl position="bottomright" />
        </MapContainer>

        <LayerToggle activeMetric={activeMetric} onChange={setActiveMetric} />
        <Legend activeMetric={activeMetric} scale={metricScale} />
        {selectedMetrics && (
          <div className="alt5-detail-panel" aria-live="polite">
            <KecamatanPopup
              activeMetric={activeMetric}
              cityAverageBeban={cityAverageBeban}
              metrics={selectedMetrics}
              onClose={closePopup}
              rank={selectedRank}
              totalRanked={rankings.length}
            />
          </div>
        )}
        <Sidebar
          activeMetric={activeMetric}
          onMetricChange={setActiveMetric}
          onSelectKecamatan={handleSidebarSelect}
          onToggle={() => setSidebarOpen((value) => !value)}
          open={sidebarOpen}
          rankings={rankings}
        />
      </main>
    </div>
  );
}
